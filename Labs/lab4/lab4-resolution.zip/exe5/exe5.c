#include <stdio.h>
#include <stdlib.h>

//This is needed by all threads
#define MAXNUM 1000
int *num_vec;
//

void mult(int vec[], int len, int n){
  int i;
  for(i=0; i< len; i++){
    if(vec[i]%n == 0)
      printf("\t\tmult %d %d\n", n, vec[i]);
  }
}

void * thread_func(void *arg){
  int n = (int) arg;
  printf("\tThread %x verifying multiples of %d\n", pthread_self() ,n );
  mult(num_vec, MAXNUM, n);
}

int main(){

  int i;
  pthread_t thread_id;

  num_vec= malloc(sizeof(int)*MAXNUM);
  if(num_vec==NULL){
    exit(-1);
  }

  for(i=0; i< MAXNUM; i++){
    num_vec[i]= random();
  }
  pthread_create(&thread_id, NULL, thread_func, 2);
  pthread_create(&thread_id, NULL, thread_func, 3);
  pthread_create(&thread_id, NULL, thread_func, 5);
  pthread_create(&thread_id, NULL, thread_func, 7);

  getchar();
  exit(0);
}
