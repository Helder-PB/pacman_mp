#include <stdio.h>
#include <stdlib.h>
#include <inttypes.h>

void *thread_func (void * arg){
  char c;
  printf("\tThread %x started\n", pthread_self() );
  do{
    c = getchar();
    printf("\t\tThread_id %x - %c \n", pthread_self(), c);
  }while(c != 'k');
  printf("\tThread %x exiting\n", pthread_self() );
}
int main(int argc, char * argv[]){
  int n_threads;
  pthread_t thread_id;
  int n;
  if(argc ==1 || sscanf(argv[1], "%d", & n_threads) != 1)
    exit(-1);

  printf("Main thread %x \n", pthread_self() );

  printf("Creating %d Threads\n", n_threads);
  for (n= 0; n < n_threads; n++)
    pthread_create(&thread_id, NULL, thread_func, NULL);

  thread_func (NULL);
  printf("Main thread %x exited\n", pthread_self() );

  // if the main thread reads a k before any of the others
  // the main thread will terminate and all threads will continue 
  pthread_exit(NULL);


}
