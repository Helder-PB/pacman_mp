/*
Change the exercise VI so that each thread, when terminating will returns the
corresponding count to the main thread.
The main thread will receive this value and print it in the screen.
Experiment the following ways to get a value out of the thread:
•	pthread_exit(count)
•	pthread_exit(&count)
•	pthread_exit(ptr)

*/

#include <stdio.h>
#include <stdlib.h>

//This is needed by all threads
#define MAXNUM 1000
int *num_vec;
//

int mult(int vec[], int len, int n){
  int i;
  int count = 0;
  for(i=0; i< len; i++){
    if(vec[i]%n == 0){
      printf("\t\tmult %d %d\n", n, vec[i]);
      count ++;
    }
  }
  return count;
}

void * thread_func(void *arg){
  int n = (int) arg;
  int count;
  printf("\tThread %x verifying multiples of %d\n", pthread_self() ,n );
  count = mult(num_vec, MAXNUM, n);
  printf("\tThread %x found %d multiples of %d\n", pthread_self() ,count, n );

  return (&count);
}

int main(){

  int i;
  pthread_t thread_id[4];

  num_vec= malloc(sizeof(int)*MAXNUM);
  if(num_vec==NULL){
    exit(-1);
  }

  for(i=0; i< MAXNUM; i++){
    num_vec[i]= random();
  }
  pthread_create(&thread_id[0], NULL, thread_func, 2);
  pthread_create(&thread_id[1], NULL, thread_func, 3);
  pthread_create(&thread_id[2], NULL, thread_func, 5);
  pthread_create(&thread_id[3], NULL, thread_func, 7);

  void * ret_val;
  pthread_join(thread_id[0], &ret_val);
  printf("Thread %x found %d multiples of %d\n", thread_id[0] ,*(int *)ret_val, 2 );

  pthread_join(thread_id[1], &ret_val);
  printf("Thread %x found %d multiples of %d\n", thread_id[1] ,*(int *)ret_val, 3 );

  pthread_join(thread_id[2], &ret_val);
  printf("Thread %x found %d multiples of %d\n", thread_id[2] ,*(int *)ret_val, 5 );

  pthread_join(thread_id[3], &ret_val);
  printf("Thread %x found %d multiples of %d\n", thread_id[3] ,*(int *)ret_val, 7 );

  exit(0);
}
