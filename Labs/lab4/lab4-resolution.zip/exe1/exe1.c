#include <stdio.h>
#include <unistd.h>
#include <signal.h>

int n;

void reset_n(int sign){
  n = 0;
  alarm(1);
}

int main(){
  n = 0;
 alarm(1);
 signal(SIGALRM, reset_n);
  while (1){
    printf("%d\n", n++);
    usleep(10000);
  }
}
