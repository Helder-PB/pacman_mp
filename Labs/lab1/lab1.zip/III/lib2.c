#include "lib.h"

void func_1(){
	printf("Better version of func 1\n");
}

void func_2(){
	printf("Better version of func 2\n");
}
